public class Main {
    public static void main(String[] args) {
        System.out.println("This is the main program");
    }
}

